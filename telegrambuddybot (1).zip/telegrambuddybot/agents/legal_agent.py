from langchain_community.tools import DuckDuckGoSearchResults
from langchain_openai import OpenAI
import re

class LegalAgent:
    def __init__(self, openai_api_key):
        self.llm = OpenAI(api_key=openai_api_key, temperature=0.1, max_tokens=1500)
        self.search_tool = DuckDuckGoSearchResults()
        
    def extract_first_link(self, text):
        url_pattern = re.compile(r"(https?://[^\s]+)")
        urls = url_pattern.findall(text)
        return urls[0] if urls else None

    def process_query(self, query):
        search_result = self.search_tool.run(query)
        link = self.extract_first_link(search_result)
        
        if not link:
            return "Не удалось найти релевантную информацию."
            
        prompt = self._create_prompt(query, search_result, link)
        return self.llm.predict(prompt)
    
    def _create_prompt(self, query, context, link):
        return f"""
        Ты юридический помощник. Твоя задача — дать структурированный ответ на русском языке.
        Используй только законы РФ и официальные источники.

        Структура ответа:
        1. Общая информация
        2. Ключевые шаги
        3. Рекомендации
        4. Источники
        5. Вывод

        Вопрос: {query}
        Контекст: {context}
        Источник: {link}

        Ответ:
        """
