from langchain_community.tools import DuckDuckGoSearchResults
from langchain_openai import ChatOpenAI
from config import ALLOWED_DOMAINS

class BusinessAgent:
    def __init__(self, openai_api_key):
        self.llm = ChatOpenAI(api_key=openai_api_key, temperature=0.01, model="gpt-4")
        self.search_tool = DuckDuckGoSearchResults()
        
    def process_query(self, query):
        search_results = self._search(query)
        filtered_results = self._filter_results(search_results)
        
        if not filtered_results:
            return "Не удалось найти информацию о подходящих бизнес-мероприятиях."
            
        return self._generate_response(filtered_results)
        
    def _search(self, query):
        return self.search_tool.invoke({
            "query": query,
            "date_range": "upcoming_events"
        })
        
    def _filter_results(self, results):
        filtered = []
        for result in results:
            if isinstance(result, dict) and result.get('url'):
                if any(domain in result['url'] for domain in ALLOWED_DOMAINS):
                    filtered.append(result)
        return filtered
        
    def _generate_response(self, results):
        combined_content = " ".join(result.get('content', '') for result in results)
        
        prompt = f"""
        Ты бизнес-помощник. Структурируй информацию о бизнес-мероприятиях.
        Укажи:
        - Даты проведения
        - Названия мероприятий
        - Ключевые темы
        - Контактную информацию

        Информация:
        {combined_content}

        Ответ:
        """
        
        return self.llm.predict(prompt)
