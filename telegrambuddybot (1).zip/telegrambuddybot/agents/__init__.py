"""
Agent package initialization.
Provides unified interface for legal and business search agents.
"""

from .legal_agent import LegalAgent
from .business_agent import BusinessAgent

__all__ = ['LegalAgent', 'BusinessAgent']
