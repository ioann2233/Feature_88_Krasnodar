import os

# Database configuration
POSTGRES_HOST = os.environ.get('PGHOST')
POSTGRES_PORT = os.environ.get('PGPORT')
POSTGRES_DB = os.environ.get('PGDATABASE')
POSTGRES_USER = os.environ.get('PGUSER')
POSTGRES_PASSWORD = os.environ.get('PGPASSWORD')
DATABASE_URL = os.environ.get('DATABASE_URL')

# API Keys
TELEGRAM_TOKEN = os.environ.get('TELEGRAM_TOKEN', '7721652146:AAE7_K6GD5x-FItDqLGzoORuOPrEtYtAhuk')
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')

# Search configuration
ALLOWED_DOMAINS = [
    "gov.ru", "edu.ru", "org.ru", "kubnews.ru", "krasnodar.ru",
    "consultant.ru", "garant.ru", "мойбизнес.рф", "мсп.рф",
    "promote.budget.gov.ru", "economy.gov.ru", "mbm.mos.ru",
    "rg.ru", "mbkuban.ru", "spb.business"
]

# Voice processing settings
TEMP_VOICE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "temp_voice")
os.makedirs(TEMP_VOICE_DIR, exist_ok=True)
