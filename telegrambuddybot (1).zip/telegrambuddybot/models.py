from datetime import datetime
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, ForeignKey, Float, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from flask_sqlalchemy import SQLAlchemy
from config import DATABASE_URL

Base = declarative_base()
engine = create_engine(DATABASE_URL or "sqlite:///bot.db")

class UserInteraction(Base):
    __tablename__ = 'user_interactions'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer)
    query_type = Column(String(50))  # 'legal' or 'business'
    query_text = Column(Text)
    response_text = Column(Text)
    timestamp = Column(DateTime, default=datetime.utcnow)
    is_voice = Column(Integer, default=0)

class SupportCategory(Base):
    __tablename__ = 'support_categories'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), unique=True)
    description = Column(Text)
    stats = relationship("CategoryStatistics", back_populates="category")

class CategoryStatistics(Base):
    __tablename__ = 'category_statistics'
    
    id = Column(Integer, primary_key=True)
    category_id = Column(Integer, ForeignKey('support_categories.id'))
    requests_count = Column(Integer, default=0)
    last_updated = Column(DateTime, default=datetime.utcnow)
    category = relationship("SupportCategory", back_populates="stats")

class UserQuestionnaire(Base):
    __tablename__ = 'user_questionnaires'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer)
    business_type = Column(String(100))
    revenue = Column(String(100))
    employees_count = Column(String(50))
    region = Column(String(100))
    business_sector = Column(String(100))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    responses = Column(JSON)  # Store additional responses if needed

# Create initial support categories
def create_initial_categories():
    categories = [
        ("money", "Деньги (гранты, стипендии, налоговые вычеты, субсидии)"),
        ("real_estate", "Недвижимость"),
        ("education", "Обучение"),
        ("marketing", "Маркетинг и продвижение"),
        ("consulting", "Консультирование"),
        ("export", "Поддержка экспорта"),
        ("registration", "Регистрация, разрешения, экспертиза"),
        ("exhibitions", "Выставки и ярмарки"),
        ("operations", "Обеспечение хозяйственной деятельности")
    ]
    
    from sqlalchemy.orm import Session
    with Session(engine) as session:
        for name, description in categories:
            if not session.query(SupportCategory).filter_by(name=name).first():
                category = SupportCategory(name=name, description=description)
                session.add(category)
        session.commit()

Base.metadata.create_all(engine)
create_initial_categories()
