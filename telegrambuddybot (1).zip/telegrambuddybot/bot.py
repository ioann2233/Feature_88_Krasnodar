import os
import telebot
import speech_recognition as sr
import requests
import json
import subprocess
import urllib.request
from langchain_openai import OpenAI
from telebot.types import ReplyKeyboardMarkup, KeyboardButton
from sqlalchemy.orm import Session
from models import engine, UserInteraction, SupportCategory, CategoryStatistics, UserQuestionnaire
from agents import LegalAgent, BusinessAgent
from utils import VoiceHandler
from config import TELEGRAM_TOKEN, OPENAI_API_KEY
from logging import getLogger, INFO
import logging
import sys

# Setup logging with file and console handlers
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# File handler
file_handler = logging.FileHandler('bot.log')
file_handler.setLevel(logging.INFO)
file_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(file_formatter)

# Console handler
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setLevel(logging.INFO)
console_formatter = logging.Formatter('%(levelname)s: %(message)s')
console_handler.setFormatter(console_formatter)

# Add handlers
logger.addHandler(file_handler)
logger.addHandler(console_handler)

# Setup logging
logger = getLogger(__name__)
logger.setLevel(INFO)

def log_info(msg): logger.info(msg)
def log_error(msg): logger.error(msg)

class UnifiedBot:
    def __init__(self):
        self.bot = telebot.TeleBot(TELEGRAM_TOKEN)
        self.llm = OpenAI(temperature=0.1)
        self.legal_agent = LegalAgent(OPENAI_API_KEY)
        self.business_agent = BusinessAgent(OPENAI_API_KEY)
        self.voice_handler = VoiceHandler()
        self.user_states = {}

    def _register_handlers(self):
        """Register all message handlers"""
        self.bot.message_handler(commands=['start', 'help'])(self.send_welcome)
        self.bot.message_handler(content_types=['voice'])(self._handle_voice)
        self.bot.message_handler(func=lambda m: m.text == "Получить статистику")(self._handle_statistics_request)
        self.bot.message_handler(func=lambda m: m.text == "Подобрать поддержку")(self._handle_questionnaire)
        self.bot.message_handler(func=lambda m: True)(self._handle_message)
        
    def _handle_voice(self, message):
        """Handle voice messages"""
        try:
            file_info = self.bot.get_file(message.voice.file_id)
            voice_file = self.voice_handler.download_voice(
                file_info.file_path,
                message.voice.file_id,
                TELEGRAM_TOKEN
            )
            text = self.voice_handler.process_voice(voice_file, message.voice.file_id)
            self.process_query(message, text, is_voice=True)
        except Exception as e:
            log_error(f"Error processing voice message: {e}")
            self.bot.reply_to(message, "Извините, не удалось обработать голосовое сообщение.")
            
    def _handle_message(self, message):
        """Handle text messages"""
        if message.from_user.id in self.user_states:
            self._handle_questionnaire(message)
        else:
            self.process_query(message, message.text)

    @property
    def bot_instance(self):
        return self.bot

    def send_welcome(self, message):
        """Send welcome message with main menu"""
        markup = ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
        markup.add(
            KeyboardButton("Юридическая помощь"),
            KeyboardButton("Юридическая информация"),
            KeyboardButton("Бизнес-мероприятия"),
            KeyboardButton("Получить статистику"),
            KeyboardButton("Подобрать поддержку"),
            KeyboardButton("Статистика по мерам поддержки")
        )
        welcome_text = '''
        Привет! Я могу помочь найти информацию. Выберите интересующий раздел:
        
        🔹 Юридическая помощь - консультации по правовым вопросам
        🔹 Юридическая информация - поиск законов и нормативных актов
        🔹 Бизнес-мероприятия - поиск выставок и конференций
        🔹 Статистика - информация по мерам поддержки
        🔹 Подбор поддержки - персональные рекомендации
        '''
        self.bot.reply_to(message, welcome_text, reply_markup=markup)

    def _handle_statistics_request(self, message):
        """Handle statistics request"""
        with Session(engine) as session:
            stats = session.query(
                SupportCategory.description,
                CategoryStatistics.requests_count
            ).join(CategoryStatistics).all()
            
            response = "📊 Статистика по мерам поддержки:\n\n"
            for description, count in stats:
                response += f"{description}: {count} запросов\n"
                
            self.bot.reply_to(message, response)

    def _handle_questionnaire(self, message):
        """Handle questionnaire flow"""
        user_id = message.from_user.id
        answer = message.text
        
        if user_id not in self.user_states:
            self.user_states[user_id] = {'state': 'business_type', 'answers': {}}
            markup = ReplyKeyboardMarkup(resize_keyboard=True)
            markup.add("ИП", "ООО", "Самозанятый")
            self.bot.reply_to(message, "Какой у вас тип бизнеса?", reply_markup=markup)
            return

        current_state = self.user_states[user_id]['state']
        self.user_states[user_id]['answers'][current_state] = answer

        if current_state == 'business_type':
            self.user_states[user_id]['state'] = 'revenue'
            markup = ReplyKeyboardMarkup(resize_keyboard=True)
            markup.add(
                "До 1 млн руб",
                "1-5 млн руб",
                "5-10 млн руб",
                "Более 10 млн руб"
            )
            self.bot.reply_to(message, "Какой примерный годовой оборот?", reply_markup=markup)
            
        elif current_state == 'revenue':
            self.user_states[user_id]['state'] = 'employees'
            markup = ReplyKeyboardMarkup(resize_keyboard=True)
            markup.add(
                "Только я",
                "2-5 человек",
                "6-15 человек",
                "16-100 человек",
                "Более 100 человек"
            )
            self.bot.reply_to(message, "Сколько сотрудников в вашей компании?", reply_markup=markup)
            
        elif current_state == 'employees':
            self.user_states[user_id]['state'] = 'region'
            self.bot.reply_to(message, "В каком регионе ведете деятельность?")
            
        elif current_state == 'region':
            self.user_states[user_id]['state'] = 'sector'
            markup = ReplyKeyboardMarkup(resize_keyboard=True)
            markup.add(
                "Торговля",
                "Услуги",
                "Производство",
                "IT",
                "Другое"
            )
            self.bot.reply_to(message, "Укажите сферу деятельности:", reply_markup=markup)
            
        elif current_state == 'sector':
            # Save questionnaire results
            answers = self.user_states[user_id]['answers']
            answers['sector'] = answer
            
            with Session(engine) as session:
                questionnaire = UserQuestionnaire(
                    user_id=user_id,
                    business_type=answers['business_type'],
                    revenue=answers['revenue'],
                    employees_count=answers['employees'],
                    region=answers['region'],
                    business_sector=answers['sector']
                )
                session.add(questionnaire)
                session.commit()
            
                # Show waiting message and generate recommendations
                waiting_msg = self.bot.reply_to(message, "⏳ Генерирую рекомендации на основе ваших ответов...")
                recommendations = self._generate_recommendations(answers)
                self.bot.delete_message(message.chat.id, waiting_msg.message_id)
                
                # Clear user state and send recommendations
                del self.user_states[user_id]
                markup = ReplyKeyboardMarkup(resize_keyboard=True)
                markup.add(
                    KeyboardButton("Получить статистику"),
                    KeyboardButton("Подобрать поддержку")
                )
                self.bot.reply_to(
                    message,
                    f"Спасибо за ответы! Вот подобранные для вас меры поддержки:\n\n{recommendations}",
                    reply_markup=markup
                )

    def _generate_recommendations(self, answers):
        prompt = f'''
        На основе следующей информации о бизнесе подберите подходящие меры поддержки:
        - Тип бизнеса: {answers['business_type']}
        - Годовой оборот: {answers['revenue']}
        - Количество сотрудников: {answers['employees']}
        - Регион: {answers['region']}
        - Сфера деятельности: {answers['sector']}
        
        Используйте информацию с сайтов:
        - мойбизнес.рф
        - мсп.рф
        - mbkuban.ru
        
        Сформируйте структурированный ответ с конкретными мерами поддержки.
        '''
        return self.llm.predict(prompt)

    def process_query(self, message, query_text, is_voice=False):
        try:
            # Handle specific button commands
            if query_text == "Юридическая помощь":
                self.bot.reply_to(message, "Задайте ваш вопрос, и я помогу найти юридическую информацию.")
                return

            # Determine query type and get response
            if self._is_business_query(query_text):
                if 'краснодар' in query_text.lower():
                    search_query = f"бизнес мероприятия выставки конференции {query_text} site:mbkuban.ru OR site:moibiz93.ru"
                    response = self.business_agent.process_query(search_query)
                else:
                    response = self.business_agent.process_query(query_text)
                query_type = 'business'
            else:
                response = self.legal_agent.process_query(query_text)
                query_type = 'legal'

            # Store interaction in database
            with Session(engine) as session:
                interaction = UserInteraction(
                    user_id=message.from_user.id,
                    query_type=query_type,
                    query_text=query_text,
                    response_text=response,
                    is_voice=int(is_voice)
                )
                session.add(interaction)
                session.commit()

            # Send response
            self.bot.reply_to(message, response)
            
        except Exception as e:
            error_msg = f"Произошла ошибка при обработке запроса: {str(e)}"
            self.bot.reply_to(message, error_msg)

    def _is_business_query(self, query):
        """Determine if query is business-related"""
        business_keywords = [
            'мероприятие', 'выставка', 'конференция', 'семинар',
            'бизнес', 'предпринимательство', 'форум'
        ]
        return any(keyword in query.lower() for keyword in business_keywords)

    def run(self):
        """Start the bot"""
        try:
            log_info("Initializing bot components...")
            
            # Register message handlers
            self._register_handlers()
            
            # Verify OpenAI API key
            if not OPENAI_API_KEY:
                log_error("OpenAI API key is missing!")
                raise ValueError("OpenAI API key is required")
            
            # Test OpenAI API key validity without exposing it
            try:
                test_response = self.llm.predict("Test")
                log_info("OpenAI API key verified and working")
            except Exception as e:
                log_error(f"OpenAI API key verification failed: {str(e)}")
                raise ValueError("Invalid OpenAI API key")
            
            # Verify database connection and tables
            log_info("Verifying database connection...")
            from sqlalchemy import text, inspect
            with Session(engine) as session:
                # Test connection
                session.execute(text("SELECT 1"))
                log_info("Database connection successful")
                
                # Verify tables exist using inspector
                inspector = inspect(engine)
                tables = ['user_interactions', 'support_categories', 'category_statistics', 'user_questionnaires']
                existing_tables = inspector.get_table_names()
                
                for table in tables:
                    if table in existing_tables:
                        log_info(f"Table '{table}' verified")
                    else:
                        log_error(f"Table '{table}' not found")
                        raise ValueError(f"Required table '{table}' is missing")
                        
            # Delete webhook before starting polling
            log_info("Removing existing webhook...")
            self.bot.delete_webhook()
            log_info("Webhook removed successfully")
            
            # Start bot polling with enhanced error handling
            log_info("Starting bot polling...")
            try:
                log_info("Bot is now running. Press Ctrl+C to stop.")
                self.bot.infinity_polling(timeout=60, long_polling_timeout=30)
            except Exception as e:
                log_error(f"Error during polling: {str(e)}")
                self.bot.stop_polling()
                raise
            
        except Exception as e:
            log_error(f"Critical error starting bot: {str(e)}")
            raise

if __name__ == "__main__":
    bot = UnifiedBot()
    bot.run()