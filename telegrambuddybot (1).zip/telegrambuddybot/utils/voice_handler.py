import os
import speech_recognition as sr
import subprocess
import urllib.request
from config import TEMP_VOICE_DIR

class VoiceHandler:
    def __init__(self):
        self.recognizer = sr.Recognizer()
        
    def process_voice(self, file_path, file_id):
        """Process voice message and return transcribed text"""
        wav_path = self._convert_to_wav(file_path)
        text = self._transcribe(wav_path)
        self._cleanup_files(file_path, wav_path)
        return text
        
    def download_voice(self, file_path, file_id, token):
        """Download voice file from Telegram"""
        url = f'https://api.telegram.org/file/bot{token}/{file_path}'
        dest_path = os.path.join(TEMP_VOICE_DIR, f'{file_id}.oga')
        urllib.request.urlretrieve(url, dest_path)
        return dest_path
        
    def _convert_to_wav(self, file_path):
        """Convert voice file to WAV format"""
        wav_path = f"{file_path}.wav"
        subprocess.run(['ffmpeg', '-i', file_path, wav_path])
        return wav_path
        
    def _transcribe(self, wav_path):
        """Transcribe WAV file to text"""
        with sr.AudioFile(wav_path) as source:
            audio = self.recognizer.record(source)
            try:
                return self.recognizer.recognize_google(audio, language="ru_RU")
            except sr.UnknownValueError:
                raise ValueError("Не удалось распознать речь")
                
    def _cleanup_files(self, *file_paths):
        """Remove temporary files"""
        for file_path in file_paths:
            try:
                os.remove(file_path)
            except OSError:
                pass
