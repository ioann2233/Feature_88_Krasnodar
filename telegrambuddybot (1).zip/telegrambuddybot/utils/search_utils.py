import re
from typing import List, Dict

def extract_links(text: str) -> List[str]:
    """Extract all URLs from text"""
    url_pattern = re.compile(r"(https?://[^\s]+)")
    return url_pattern.findall(text)

def filter_domains(urls: List[str], allowed_domains: List[str]) -> List[str]:
    """Filter URLs by allowed domains"""
    return [url for url in urls if any(domain in url for domain in allowed_domains)]

def parse_search_results(results: List[Dict]) -> str:
    """Parse and format search results"""
    formatted_results = []
    for result in results:
        if isinstance(result, dict):
            title = result.get('title', '')
            content = result.get('content', '')
            url = result.get('url', '')
            if title and content and url:
                formatted_results.append(f"### {title}\n{content}\nИсточник: {url}\n")
    return "\n".join(formatted_results)
